document.addEventListener('DOMContentLoaded', () => {

    // Mobile menu toggle
    const menuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    const headerRight = document.querySelector('.header-right'); // Get the right-side container

    if (menuToggle && navLinks && headerRight) {
        menuToggle.addEventListener('click', () => {
            // Toggle the 'active' class on the navigation links <ul>
            navLinks.classList.toggle('active');
            
            // Also toggle the header-right section for mobile view
            headerRight.classList.toggle('active');
        });
    }

});